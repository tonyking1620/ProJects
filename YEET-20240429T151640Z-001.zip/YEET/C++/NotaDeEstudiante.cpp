#include<iostream>

using namespace std;

int main(){

    float nota,nota2,nota3,notafinal;
    
    cout<<"Primera Nota ";
    cin>>nota;

    cout<<"Segunga Nota ";
    cin>>nota2;

    cout<<"Tercera Nota ";
    cin>>nota3;

    notafinal = (nota + nota2 + nota3) / 3;
    



    cout<<"La nota final de Tony es de: "<<notafinal;



}
