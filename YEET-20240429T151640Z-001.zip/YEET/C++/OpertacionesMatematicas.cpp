#include<iostream>

using namespace std;

int main(){
     
     int n1 = 0;
     int n2 = 0;
     int suma = 0;
     int resta = 0;
     int multiplicacion = 0;
     int divicion = 0;
      


     cout<<"Que numero para el primer numero1";
     cin>> n1;

     cout<<"que numero para el segundo numero2";
     cin>> n2;

     suma = n1 + n2;
     resta = n1 - n2;
     multiplicacion = n1 * n2;
     divicion = n1 / n2;

     cout<<"El resultado de suma es "<<suma<<endl;
     cout<<"El resultado de resta es "<<resta<<endl;
     cout<<"El resultado de multiplicacion es "<<multiplicacion<<endl;
     cout<<"El resultado de divicion es "<<divicion<<endl;




}
