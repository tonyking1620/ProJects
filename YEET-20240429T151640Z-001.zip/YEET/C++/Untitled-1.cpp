#include <iostream>

using namespace std;

int main(){
    
     int numero;


     cout<<"dime perro";
     cin>>numero;

     cout<<"el perro este me tiene mal "<<numero;

}