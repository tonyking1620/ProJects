#include<iostream>
#include<iomanip>

using namespace std;

int main(){
    
    float precio = 0;
    float ivu = 0.115;
    float total= 0;
    cout<<"Ponga el precio"<<endl;
    cin>>precio;

    total = precio * ivu;
    precio = precio + total;
     
    cout<<"El precio final seria "<<fixed<<setprecision(2)<<precio<<endl;



} 