using System;
using System.IO;
using System.Text;

namespace Orientado a objetos
{
   public class main_class
   {
      static System.Random random_generator = new System.Random();
      public static void Main(string[] args)
      {
         string raptor_prompt_variable_zzyz;
         ?? resultado;
         ?? num;
         ?? num2;
      
         num =0;
         num2 =0;
         Resultado =0;
         raptor_prompt_variable_zzyz ="Dame numero 1";
         Console.WriteLine(raptor_prompt_variable_zzyz);
         num= Double.Parse(Console.ReadLine());
         raptor_prompt_variable_zzyz ="Dame numero 2";
         Console.WriteLine(raptor_prompt_variable_zzyz);
         num2= Double.Parse(Console.ReadLine());
         Resultado =num+num2;
         Console.WriteLine("Resultado es: "+Resultado);
      }
   }
}
