# -*- coding: utf-8 -*-
"""
Created on Tue Feb 23 13:47:41 2021

@author: Tony
"""
cantidad = int(1)
serie = ""

tamano = int(input("Entre el tamano de la serie:"))


regla = int(input("Seleccione 1 o 2:"))
 
if regla == 1:
    sumar = int(input("Por cuanto quieres que sume?"))
    numero = int(sumar)
    while cantidad < tamano:
        if cantidad <= tamano:
         serie = (serie + str(sumar) + ",")
         cantidad += 1
         sumar += numero
    serie = (serie + str(sumar))  
     
elif regla == 2:
     numero = int(0)
     numero2 = int(1)
     resultado = int(0)
     serie = (serie + str(numero) + "," + str(numero2) + ",")
     tamano = (tamano - 2)
     while cantidad < tamano:
        if cantidad <= tamano:
            resultado = (numero2 + numero)
            serie = (serie + str(resultado) + ",")
            numero = numero2
            numero2 = resultado
            cantidad += 1
     resultado = (numero2 + numero)   
     serie = (serie + str(resultado)) 

    

else:
    print("error")
                    
     
      
print(serie)
    