import discord
import os
import asyncio
import config
import nextcord

client = discord.Client()
id = str()
conteo = int(1)


@client.event 
async def on_ready():
    print('Let the counting begin')




@client.event 
async def on_message(message):
  global id
  global conteo
  conteo = str(conteo)
  

  if message.author.id != id:
    if '' in message.content == conteo:
       conteo = int(conteo)
       conteo += 1
       id = message.author.id
       print("conteo")
    
    else:
        if message.author == client.user:
            return
        if message.author.bot: return
        await message.delete()
        channel = client.get_channel(966815739178799184)
        mention = message.author.mention
        await channel.send("Ese no es " + mention)
  else:
    if message.author == client.user:
        return
    if message.author.bot: return
    await message.delete()
    channel = client.get_channel(966815739178799184)
    mention = message.author.mention
    await channel.send("Espera a que otro ponga numero" + mention)          
        
 
 

client.run(config.TOKEN)