# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 17:21:50 2023

@author: Tony
"""

palabra = ""
contador = 0

palabra = (input("Escriba hola:   "))

for ciclo in (1,3):
    if palabra == "hola":
        print("")
    else:
        palabra = (input("Esa no es la palbra pongala de nuevo:   "))
        contador = ciclo
       
                  
                  
if contador == 3:
    print ("Fin del juego")
    
else:
    print("Felicidades")