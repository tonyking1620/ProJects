# -*- coding: utf-8 -*-
"""
Created on Mon Feb 22 18:43:19 2021

@author: Tony
"""
numero1 = int(input("Entra el primer numero:"))
numero2 = int(input("Entra el segundo numero:"))

contador = 1

if numero1*2 > numero2:
    numero2 = (numero1 * 2)

while contador <= 10:
    resultado = (numero1 + numero2)
    print ("El Resultado de la suma " + str(numero1) + "+" + str(numero2) + "=" + str(resultado))
    numero1 +=1
    numero2 +=1
    contador +=1
