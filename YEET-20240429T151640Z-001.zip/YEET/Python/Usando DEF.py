contador = int(0)
def tabla(n):
    for i in range (0,11):
        global contador
        print (n * contador) 
        contador += 1
        
n = int(input("numero"))

tabla(n)
        
    
    
                  
                  
                  
                
