import tkinter as tk
import pickle

# Función para agregar un elemento al inventario
def add_item():
    item_name = entry_name.get()
    item_quantity = entry_quantity.get()

    # Agregar el elemento al diccionario del inventario
    inventory[item_name] = item_quantity

    # Actualizar la lista de elementos en la pantalla
    update_list()

    # Limpiar las entradas después de agregar el elemento
    entry_name.delete(0, tk.END)
    entry_quantity.delete(0, tk.END)

# Función para quitar un elemento del inventario
def remove_item():
    item_name = entry_name.get()
    item_quantity = entry_quantity.get()

    # Verificar si el elemento existe en el inventario
    if item_name in inventory:
        # if item_quantity.isdigit() Verificar si la cantidad a quitar es válida Si isdigit() devuelve False, significa que la cantidad introducida no es un número y se deben mostrar un mensaje de error para indicar al usuario que introduzca una cantidad válida.
        if item_quantity.isdigit() and int(item_quantity) <= int(inventory[item_name]):
            # Reducir la cantidad del elemento en el inventario
            inventory[item_name] = str(int(inventory[item_name]) - int(item_quantity))

            # Actualizar la lista de elementos en la pantalla
            update_list()

            # Limpiar las entradas después de quitar el elemento
            entry_name.delete(0, tk.END)
            entry_quantity.delete(0, tk.END)
        else:
            print("Cantidad inválida")
    else:
        print("Elemento no encontrado en el inventario")

    # Actualizar la lista de elementos en la pantalla
    update_list()

    # Limpiar las entradas después de quitar el elemento
    entry_name.delete(0, tk.END)
    entry_quantity.delete(0, tk.END)


#Funcion para sumar
def suma_item():
    item_name = entry_name.get()
    item_quantity = entry_quantity.get()

    # Verificar si el elemento existe en el inventario
    if item_name in inventory:
        # if item_quantity.isdigit() Verificar si la cantidad a quitar es válida Si isdigit() devuelve False, significa que la cantidad introducida no es un número y se deben mostrar un mensaje de error para indicar al usuario que introduzca una cantidad válida.
        if item_quantity.isdigit() and int(item_quantity) >= int(inventory[item_name]):
            # Aumentar la cantidad del elemento en el inventario
            inventory[item_name] = str(int(inventory[item_name]) + int(item_quantity))

            # Actualizar la lista de elementos en la pantalla
            update_list()

            # Limpiar las entradas después de quitar el elemento
            entry_name.delete(0, tk.END)
            entry_quantity.delete(0, tk.END)
        else:
            print("Cantidad inválida")
    else:
        print("Elemento no encontrado en el inventario")

    # Actualizar la lista de elementos en la pantalla
    update_list()

    # Limpiar las entradas después de quitar el elemento
    entry_name.delete(0, tk.END)
    entry_quantity.delete(0, tk.END)
    

# Función para Eliminar un elemento del inventario
def delete_item():
    item_name = entry_name.get()

    # Actualizar el elemento en el diccionario del inventario
    del inventory[item_name] 

    # Actualizar la lista de elementos en la pantalla
    update_list()

    # Limpiar las entradas después de actualizar el elemento
    entry_name.delete(0, tk.END)
    entry_quantity.delete(0, tk.END)

#Funcion de Click
def onclick(event):
    seleccion = listbox.get(listbox.curselection())
    item_name, item_quantity = seleccion.split(": ")
    entry_name.delete(0, tk.END)
    entry_name.insert(0, item_name)
    entry_quantity.delete(0, tk.END)
    entry_quantity.insert(0, item_quantity)


# Función para actualizar la lista de elementos en la pantalla
def update_list():
    listbox.delete(0, tk.END)
    for key, value in inventory.items():
        listbox.insert(tk.END, key + ": " + str(value))

# Función para guardar el inventario en un archivo pickle
def save_inventory():
    with open("inventory.pickle", "wb") as f:
        pickle.dump(inventory, f)

# Función para cargar el inventario desde un archivo pickle
def load_inventory():
    global inventory
    try:
        with open("inventory.pickle", "rb") as f:
            inventory = pickle.load(f)
    except:
        pass
    update_list()

# Inicializar el diccionario del inventario
inventory = {}

# Crear la ventana principal de Tkinter
root = tk.Tk()
root.title("Inventario")
root.geometry("400x400")

# Crear las entradas para el nombre y la cantidad del elemento
entry_name = tk.Entry(root)
entry_quantity = tk.Entry(root)

#Colocar las entradas en la ventana
entry_name.grid(row=0, column=0)
entry_quantity.grid(row=0, column=1)

#Crear los botones para agregar, quitar y actualizar elementos
button_add = tk.Button(root, text="Agregar", command=add_item)
button_suma = tk.Button(root, text="Suma", command=suma_item)
button_remove = tk.Button(root, text="Restar", command=remove_item)
button_delete = tk.Button(root, text="Eliminar", command=delete_item)

#Colocar los botones en la ventana
button_add.grid(row=1, column=0)
button_suma.grid(row=2,column=0)
button_remove.grid(row=2, column=2)
button_delete.grid(row=1, column=2)

#Crear la lista de elementos en la pantalla
listbox = tk.Listbox(root)
listbox.bind("<<ListboxSelect>>", onclick)

#Colocar la lista en la ventana
listbox.grid(row=2, columnspan=3)

#Crear los botones para guardar y cargar el inventario
button_save = tk.Button(root, text="Guardar", command=save_inventory)
button_load = tk.Button(root, text="Cargar", command=load_inventory)

#Colocar los botones en la ventana
button_save.grid(row=3, column=0)
button_load.grid(row=3, column=2)

#Cargar el inventario desde un archivo pickle
load_inventory()

#Iniciar el bucle de eventos de Tkinter
root.mainloop()



