import discord
import os
import asyncio
import config

client = discord.Client()

@client.event 
async def on_ready():
    print('cheking :b')


@client.event
async def status(user):
  user = get(bot.get_all_members()
  print ('echo')

  