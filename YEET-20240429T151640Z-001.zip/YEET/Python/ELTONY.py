# -*- coding: utf-8 -*-
"""
Created on Tue Feb  9 09:05:03 2021

@author: Tony
"""
RESULTADO = 0

NUM1 = int(input("Entra valor 1: "))
NUM2 = int(input ("Entra valor 2: "))
opcion = int(input ("Escoge entre 1 al 3: "))
contador = 1
if opcion == 1:
    while contador <= 10:
      print(contador)
      RESULTADO = (NUM1) + (NUM2)
      print("La suma de " + str(NUM1) + "+" + str(NUM2) + "=" + str(RESULTADO))
      contador += 1
      NUM1 += 1
      NUM2 += 1
      
      
elif opcion == 2:
   while contador < 10:
     RESULTADO = (NUM1)-(NUM2)
     print("RESUltado es ", RESULTADO)
     contador += 1

elif opcion == 3:   
  while contador < 10:  
   RESULTADO = (NUM1)*(NUM2)
   print("RESUltado es ", RESULTADO)
   contador += 1

else:
 print ("Numero no existe")
           