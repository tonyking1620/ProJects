# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 17:03:00 2022

@author: Tony
"""

conteo = str(1)

speak = str(input(""))
    
print(conteo + " 1" + speak)
