import random
import discord
import os
import asyncio
import config

client = discord.Client()
respuesta = str("")

@client.event 
async def on_ready():
  global respuesta
  
  print('Let the counting begin')
  pregunta = random.randint(0,15)
  if pregunta == 1:
    channel = client.get_channel(963887989925236846)
    await channel.send("¿Qué es lo que se hace de noche, que no se puede hacer de día y todo universitario pasa por eso?")
    respuesta = ("Trasnocharse")
    
  elif pregunta == 2:
    channel = client.get_channel(963887989925236846)
    await channel.send("Tengo ocho patas cargadas de ventosas y paseo por las rocas meciéndome en las olas. ¿Quién soy?")
    respuesta = ("Pulpo")
    
  elif pregunta == 3:
    channel = client.get_channel(963887989925236846)
    await channel.send("Alas de mil colores y se pierden entre las flores.")
    respuesta = ("Mariposa")

  elif pregunta == 4:
    channel = client.get_channel(963887989925236846)
    await channel.send("Aunque no soy florista, trabajo con flores y el hombre disfruta el fruto de mis labores")
    respuesta = ("Abeja")
    
  elif pregunta == 5:
    channel = client.get_channel(963887989925236846)
    await channel.send("Por decir muchas mentirasme creció la nariz; pero, arrepentido luego, volví a sentirme feliz.")
    respuesta = ("Pinocho")
    
  elif pregunta == 6:
    channel = client.get_channel(963887989925236846)
    await channel.send("Dios del trueno, hijo de Odín ,con fuerza sobre humana empuña el Mjölnir con mucha gana.")
    respuesta = ("Thor")
    
  elif pregunta == 7:
    channel = client.get_channel(963887989925236846)
    await channel.send("El trepamuros que se guardó un lugar en nuestros corazones por su cercanía, humanidad, simpatía, vulnerabilidady hasta por su aparente simpleza en ocasiones. ¿Quién podría ser?")
    respuesta = ("Spiderman")
    
  elif pregunta == 8:
    channel = client.get_channel(963887989925236846)
    await channel.send("El es un superhombre con poderes sobrenaturales que solo tiene un punto débil, una famosa roca verde. ¿Quién es?")
    respuesta = ("Superman")
    
  elif pregunta == 9:
    channel = client.get_channel(963887989925236846)
    await channel.send("Tiene un cuadrado de envase, una base redonda y una porción triangular.")
    respuesta = ("Pizza")
    
  elif pregunta == 10:
    channel = client.get_channel(963887989925236846)
    await channel.send("Con caras muy blancas llenas de lunares a unos damos suerte, a otros, pesares.")
    respuesta = ("Dados")
    
  elif pregunta == 11:
    channel = client.get_channel(963887989925236846)
    await channel.send("Chico enamoradizo que tiene especial debilidad por ciertas trabajadoras sanitarias y policias")
    respuesta = ("Brook") 
    
  elif pregunta == 12:
    channel = client.get_channel(963887989925236846)
    await channel.send("Redondo como la luna y blanco como la cal. Me hacen de leche… ¡y ya no te digo más!")
    respuesta = ("Queso")  

  elif pregunta == 13:
    channel = client.get_channel(963887989925236846)
    await channel.send("Blanca por dentro, verde por fuera. Si quieres que te lo diga, espera.")
    respuesta = ("Pera")  

  elif pregunta == 14:
    channel = client.get_channel(963887989925236846)
    await channel.send("En la mesa me ponen y sobre mí todos comen.")
    respuesta = ("Plato")  
    
  elif pregunta == 15:
    channel = client.get_channel(963887989925236846)
    await channel.send("!******, te elijo a ti")
    respuesta = ("Pokemon")
    
@client.event 
async def on_message(message):
  global respuesta

  if '' in message.content == respuesta:
     channel = client.get_channel(963888039350898778)
     mention = message.author.mention
     await channel.send("Ganador es " + mention + ":tada:")
     os.system("python main.py")
 

client.run(config.TOKEN)