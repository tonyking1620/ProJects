# -*- coding: utf-8 -*-
"""
Created on Sat Jan 29 13:36:39 2022

@author: Tony
"""
def greet(first_name, last_name):
    print(f"Hi {first_name} {last_name}")
    print("Welcome aboard")
    
    
greet(1,2)





                   
    
            