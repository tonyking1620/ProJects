#include <iostream>
#include <string>

using namespace std;
int main()
{
   string raptor_prompt_variable_zzyz;
   ?? regla;
   ?? numero2;
   ?? tamano;
   ?? cantidad;
   ?? serie;
   ?? resultado;
   ?? numero;
   ?? sumar;

   tamano =0;
   regla =0;
   raptor_prompt_variable_zzyz ="Entra el tamano de la serie: ";
   cout << raptor_prompt_variable_zzyz << endl;
   cin >> tamano;
   raptor_prompt_variable_zzyz ="Seleccione 1 o 2";
   cout << raptor_prompt_variable_zzyz << endl;
   cin >> regla;
   cantidad =1;
   serie ="";
   if (regla==1)
   {
      raptor_prompt_variable_zzyz ="Por cuanto quieres que se sume?";
      cout << raptor_prompt_variable_zzyz << endl;
      cin >> sumar;
      numero =sumar;
      while (!(cantidad>tamano))
      {
         if (cantidad==tamano)
         {
            serie =serie+sumar;
         }
         else
         {
            serie =serie+sumar+",";
         }
         sumar =numero+sumar;
         cantidad =cantidad+1;
      }
   }
   else
   {
      if (regla==2)
      {
         resultado =0;
         numero =0;
         numero2 =1;
         serie =serie+numero+","+numero2+",";
         tamano =tamano-2;
         while (!(cantidad>tamano))
         {
            if (cantidad==tamano)
            {
               resultado =numero2+numero;
               serie =serie+resultado;
            }
            else
            {
               resultado =numero2+numero;
               serie =serie+resultado+",";
            }
            numero =numero2;
            numero2 =resultado;
            cantidad =cantidad+1;
         }
      }
      else
      {
         cout << "Regla no existe" << endl;      }
   }
   cout << ""+serie << endl;
   return 0;
}
