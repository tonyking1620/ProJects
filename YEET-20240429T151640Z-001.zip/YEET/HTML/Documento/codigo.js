var ruta = window.location;
console.log(ruta);
document.write("Estás en: " + ruta);
