using System;
using System.IO;
using System.Text;

namespace Fuck
{
   public class main_class
   {
      static System.Random random_generator = new System.Random();
      public static void Main(string[] args)
      {
         string raptor_prompt_variable_zzyz;
         ?? nombre;
         ?? numero;
      
         nombre ="";
         numero =0;
         raptor_prompt_variable_zzyz ="Escriba su nombre";
         Console.WriteLine(raptor_prompt_variable_zzyz);
         nombre= Double.Parse(Console.ReadLine());
         raptor_prompt_variable_zzyz ="Cuantas veces quieres que lo repita?";
         Console.WriteLine(raptor_prompt_variable_zzyz);
         numero= Double.Parse(Console.ReadLine());
         while (1)
         {
            Console.WriteLine(""+nombre);
            numero =numero-1;
            if (0==numero)) break;
         }
      }
   }
}
