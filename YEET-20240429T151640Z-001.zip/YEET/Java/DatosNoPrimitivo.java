public class DatosNoPrimitivo {

    public static void main(String[]arg){
    String palabra = "Este wey";


    System.out.println(palabra);


    }
    
}
