import java.util.Scanner;

public class Clasificaciones {

    public static void main(String[]arg){
    try (Scanner entrada = new Scanner(System.in)) {
        float nota1,nota2,nota3,suma;
        System.out.println("Digite 3 notas");
        nota1 = entrada.nextInt();
        nota2 = entrada.nextInt();
        nota3 = entrada.nextInt();

        suma = nota1 + nota2 + nota3;
        suma = suma / 3;

        System.out.println("La nota final es de " + suma);
    }
    }

}
