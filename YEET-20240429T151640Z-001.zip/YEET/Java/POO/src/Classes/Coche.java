package Classes;

    public class Coche {
       //Atributos
    String color;
    String marca;
    int km;
   
   
    public static void main(String[]args){
   
        Coche coche1 = new Coche();
   
        coche1.color = "Blanco";
        coche1.marca = "Audi";
        coche1.km = 0;
   
   
        System.out.println("El color del choche es: "+ coche1.color);
        System.out.println("La marca es: "+ coche1.marca);
        System.out.println("El coche tiene: " + coche1.km);
   
   
    }
       
}
   

