package Metodos;

import javax.swing.JOptionPane;

public class Metodo {

    int numero1;
    int numero2;
    int suma;
    int resta;
    int mult;
    int div;
    


    public void leerNumeros(){

        numero1 = Integer.parseInt(JOptionPane.showInputDialog("digite numero"));
        numero2 = Integer.parseInt(JOptionPane.showInputDialog("digite numero"));


        
    }

    public void suma(){

        suma = numero1 + numero2;
    }

    public void resta(){

        resta = numero1 - numero2;
    }

    public void mult(){

        mult = numero1 * numero2;
    }

    public void div(){

        div = numero1 / numero2;
    }

    public void resultados(){


        System.out.println(suma);
        System.out.println(resta);
        System.out.println(mult);
        System.out.println(div);
    }

    
}

