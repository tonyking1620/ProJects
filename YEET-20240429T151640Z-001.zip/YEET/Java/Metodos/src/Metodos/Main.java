package Metodos;

public class Main {

    public static void main(String[]args){

        Metodo op = new Metodo();

        op.leerNumeros();
        op.suma();
        op.resta();
        op.mult();
        op.div();
        op.resultados();
    }
    
}
