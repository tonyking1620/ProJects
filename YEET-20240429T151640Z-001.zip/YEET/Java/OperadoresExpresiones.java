import java.util.Scanner;

public class OperadoresExpresiones {

    public static void main(String[]args){

        Scanner entrada = new Scanner(System.in);

        int entero1,entero2,suma,resta,mult,div,resto;

        System.out.println("Digite 2 numeros: ");
        entero1 = entrada.nextInt();
        entero2 = entrada.nextInt();
        suma = entero1 + entero2;
        resta = entero1 - entero2;
        div = entero1 / entero2;
        mult = entero1 * entero2;
        resto = entero1 % entero2;

        System.out.println(""+suma);
        System.out.println(""+resta);
        System.out.println(""+div);
        System.out.println(""+mult);
        System.out.println(""+resto);



    }
    
    
}
