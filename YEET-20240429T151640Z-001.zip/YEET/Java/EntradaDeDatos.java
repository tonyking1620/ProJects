
import java.util.Scanner;
public class EntradaDeDatos {


    public static void main(String[]arg){

        Scanner entrada = new Scanner(System.in);
        int numero;

        System.out.println("Diga numero");
        numero = entrada.nextInt();

        System.out.println("El numero es: " + numero);

        Scanner entrada2 = new Scanner(System.in);
        float numero2;

        System.out.println("Diga numero");
        numero2 = entrada2.nextFloat();

        System.out.println("El numero es: " + numero2);

        String cadena;

        System.out.println("Digite una cadena");
        cadena = entrada.nextLine();

        System.out.println(cadena);
    }
    
}
