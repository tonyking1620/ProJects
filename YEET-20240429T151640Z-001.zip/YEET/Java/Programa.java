public class Programa {
    


    public static void main (String[]arg) {
        boolean hola = true;

        System.out.println("El numero es: "+hola);

    }
}
