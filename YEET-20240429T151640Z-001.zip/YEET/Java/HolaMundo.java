public class HolaMundo{
    public static void main (String[]args) {
        System.out.println("Hola mundo");
        
        System.out.println("H"); 
        System.out.println();

    }
}