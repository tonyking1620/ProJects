public class Constante{

    public static void main(String[]args){
    
    final int numero = 10;
    
    System.out.println(numero);
         
    
    
        }
}
    
