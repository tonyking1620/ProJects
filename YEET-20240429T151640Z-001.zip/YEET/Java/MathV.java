import java.util.Scanner;
import java.util.function.DoubleToIntFunction;
public class MathV {
    public static void main(String[]args){

        double raiz = Math.sqrt(9.0);
        double base = 5, exponente = 2;
        double resultado = Math.pow(base, exponente);
        float numero = 4.56f;
        int resultado2 = Math.round(numero);

        System.out.println(raiz);
        System.out.println(resultado);
        System.out.println(resultado2);



    }
}
