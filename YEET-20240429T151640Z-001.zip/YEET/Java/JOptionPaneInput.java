import javax.swing.JOptionPane;

public class JOptionPaneInput {
    
    public static void main(String[]args) {

        String cadena;
        int entero;
        char letra;
        double decimal;

        cadena = JOptionPane.showInputDialog("Digite cadena");
        entero = Integer.parseInt(JOptionPane.showInputDialog ("Digite entero"));
        letra = JOptionPane.showInputDialog("Ponga letra ").charAt(0);
        decimal = Double.parseDouble(JOptionPane.showInputDialog("Digite decimal"));
        
        JOptionPane.showMessageDialog(null,"La cadena es: "+cadena);
        JOptionPane.showMessageDialog(null,"El numero es: "+entero);
        JOptionPane.showMessageDialog(null,"La letra es: "+letra);
        JOptionPane.showMessageDialog(null,"El decimal es: "+decimal);

    }
}
