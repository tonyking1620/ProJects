import java.util.Scanner;
public class Ejercicio3 {
    public static void main(String[]args){

        Scanner entrada = new Scanner(System.in);

        int guillermo = 0;
        int luis = 0;
        int juan = 0;
        int total = 0;

        System.out.println("Cuanto tiene Guillermo:");

        guillermo = entrada.nextInt();

        luis = guillermo / 2;
        juan = guillermo + luis /2;
        total =  guillermo + juan + luis;

        System.out.println("El total es: " + total);
    }
    
}
