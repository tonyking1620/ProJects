﻿// See https://aka.ms/new-console-template for more information 
Console.WriteLine("Hello, World!");
Console.Beep();

Console.WriteLine("Nombre?");
String name = Console.ReadLine();

Console.WriteLine("Edad?");
int age = Convert.ToInt32(Console.ReadLine());

sing(name , age);


static void sing(String name, int age)
{
    
    Console.WriteLine("SingHI " + name + " Tienes " + age);
    Console.WriteLine("SingHi " + name + " Tienes " + age);

}


double x = 3;
double pow = Math.Pow(x, 2);
Console.WriteLine(pow);

Random random = new Random();
int num = random.Next() + 100;
Console.WriteLine(num);

Console.WriteLine("Entra el lado A");
double a = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Entra el lado B");
double b = Convert.ToInt32(Console.ReadLine());

double c = Math.Sqrt((a*a) + (b*b));
Console.WriteLine("La hipotenusa es: " + c);

String Name = "tony";
Name = Name.ToUpper();
Console.WriteLine("El nombre " + Name + " tiene " + Name.Length + "characters");
String Phone = "187-586-3489";
Phone = Phone.Replace("-" , "");
Console.WriteLine(Phone);

