﻿using System;
using ConsoleGUI;
using ConsoleGUI.Controls;

public class Room
{
    public string Description { get; set; }
    public Room NorthRoom { get; set; }
    public Room EastRoom { get; set; }
    public Room SouthRoom { get; set; }
    public Room WestRoom { get; set; }
}

public class Adventurer
{
    public Room CurrentRoom { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
}

public class AdventureGame
{
    private Room initialRoom;
    private Room currentRoom;
    private Adventurer player;
    private GUIManager gui;

    public AdventureGame()
    {
        player = new Adventurer();
        initialRoom = CreateGameWorld();
        currentRoom = initialRoom;
        player.CurrentRoom = currentRoom;
        player.X = 0;
        player.Y = 0;

        // Inicializa el GUIManager
        gui = new GUIManager();
    }

    public Room CreateGameWorld()
    {
        Room room1 = new Room { Description = "Sala 1" };
        Room room2 = new Room { Description = "Sala 2" };
        Room room3 = new Room { Description = "Sala 3" };

        room1.EastRoom = room2;
        room2.WestRoom = room1;
        room2.SouthRoom = room3;
        room3.NorthRoom = room2;

        return room1;
    }

    public void ShowGameStartScreen()
    {
        Console.WriteLine("¡Bienvenido al juego de aventuras!");
        Console.WriteLine("Estás en un misterioso calabozo. Tu objetivo es encontrar el cofre del tesoro.");
    }

    public void ShowRoomDescription()
{
    // Borra la consola y crea un lienzo para dibujar
    Console.Clear();
    Canvas canvas = new Canvas(Console.WindowWidth, Console.WindowHeight);

    // Dibuja las habitaciones en un área de 6x6 alrededor del jugador
    for (int i = player.Y - 2; i <= player.Y + 3; i++)
    {
        for (int j = player.X - 2; j <= player.X + 3; j++)
        {
            string roomRepresentation;
            if (i == player.Y && j == player.X)
            {
                roomRepresentation = "P";
            }
            else if (currentRoom.NorthRoom != null && currentRoom.NorthRoom == GetRoom(j, i))
            {
                roomRepresentation = ".";
            }
            else if (currentRoom.EastRoom != null && currentRoom.EastRoom == GetRoom(j, i))
            {
                roomRepresentation = ".";
            }
            else if (currentRoom.SouthRoom != null && currentRoom.SouthRoom == GetRoom(j, i))
            {
                roomRepresentation = ".";
            }
            else if (currentRoom.WestRoom != null && currentRoom.WestRoom == GetRoom(j, i))
            {
                roomRepresentation = ".";
            }
            else
            {
                roomRepresentation = "X";
            }

            // Corrige la sintaxis para dibujar en el lienzo usando canvas.DrawString
            canvas.DrawString(j - (player.X - 2), i - (player.Y - 2), roomRepresentation);
        }
    }

    // Corrige la sintaxis para mostrar el texto en el lienzo
    canvas.DrawString(3, 3, $"Estás en {currentRoom.Description}");
    canvas.DrawString(3, 4, "Comandos disponibles: IR NORTE, IR ESTE, IR SUR, IR OESTE, IR NORESTE, IR NOROESTE, IR SURESTE, IR SUROESTE, SALIR");

    // Renderiza el lienzo en la consola
    gui.Render(canvas);
}

    private Room GetRoom(int x, int y)
    {
        if (x == player.X && y == player.Y - 1)
        {
            return currentRoom.NorthRoom;
        }
        else if (x == player.X + 1 && y == player.Y)
        {
            return currentRoom.EastRoom;
        }
        else if (x == player.X && y == player.Y + 1)
        {
            return currentRoom.SouthRoom;
        }
        else if (x == player.X - 1 && y == player.Y)
        {
            return currentRoom.WestRoom;
        }
        else
        {
            return null;
        }
    }

    public void ExecutePlayerCommand(string cmd)
    {
        switch (cmd.ToUpper())
        {
            case "IR NORTE":
                if (currentRoom.NorthRoom != null)
                {
                    currentRoom = currentRoom.NorthRoom;
                    player.Y--;
                }
                break;
            case "IR ESTE":
                if (currentRoom.EastRoom != null)
                {
                    currentRoom = currentRoom.EastRoom;
                    player.X++;
                }
                break;
            case "IR SUR":
                if (currentRoom.SouthRoom != null)
                {
                    currentRoom = currentRoom.SouthRoom;
                    player.Y++;
                }
                break;
            case "IR OESTE":
                if (currentRoom.WestRoom != null)
                {
                    currentRoom = currentRoom.WestRoom;
                    player.X--;
                }
                break;
            case "IR NORESTE":
                if (currentRoom.NorthRoom != null && currentRoom.NorthRoom.EastRoom != null)
                {
                    currentRoom = currentRoom.NorthRoom.EastRoom;
                    player.Y--;
                    player.X++;
                }
                break;
            case "IR NOROESTE":
                if (currentRoom.NorthRoom != null && currentRoom.NorthRoom.WestRoom != null)
                {
                    currentRoom = currentRoom.NorthRoom.WestRoom;
                    player.Y--;
                    player.X--;
                }
                break;
            case "IR SURESTE":
                if (currentRoom.SouthRoom != null && currentRoom.SouthRoom.EastRoom != null)
                {
                    currentRoom = currentRoom.SouthRoom.EastRoom;
                    player.Y++;
                    player.X++;
                }
                break;
            case "IR SUROESTE":
                if (currentRoom.SouthRoom != null && currentRoom.SouthRoom.WestRoom != null)
                {
                    currentRoom = currentRoom.SouthRoom.WestRoom;
                    player.Y++;
                    player.X--;
                }
                break;
            default:
                Console.WriteLine("Comando no válido. Inténtalo de nuevo.");
                break;
        }
    }

    public bool CheckGameOver()
    {
        return false;
    }

    public void ShowGameOverScreen()
    {
        Console.WriteLine("Juego terminado. ¡Gracias por jugar!");
    }

    public void Init()
    {
    }

    public string GetPlayerCommand()
    {
        Console.Write("Comando: ");
        return Console.ReadLine();
    }

    public static void Main(string[] args)
    {
        AdventureGame game = new AdventureGame();
        game.Init();
        game.ShowGameStartScreen();
        while (!game.CheckGameOver())
            {
            game.ShowRoomDescription();
            string command = game.GetPlayerCommand();
            game.ExecutePlayerCommand(command);
        }

        game.ShowGameOverScreen();
    }
}

